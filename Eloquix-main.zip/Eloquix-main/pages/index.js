import Head from 'next/head'
import Image from 'next/image'

import 'bootstrap/dist/css/bootstrap.css'

export default function Home() {
  return (
    <>
    <Head> <meta name="viewport" content="width=device-width, initial scale=1" /></Head>
    <h1>Hello World</h1>
    </>
  )
}
